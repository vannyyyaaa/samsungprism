from taming.modules.losses.vqperceptual import DummyLoss

