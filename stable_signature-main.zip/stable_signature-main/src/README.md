The repositories present in this folder are based on the following repositories:

- Taming Transformers for High-Resolution Image Synthesis: https://github.com/CompVis/taming-transformers
- Latent Diffusion Models: https://github.com/CompVis/latent-diffusion
- Perceptual Similarity: https://github.com/SteffenCzolbe/PerceptualSimilarity